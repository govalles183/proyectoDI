package vista;

import controlador.EstudianteController;
import modelo.Usuario;
import javax.swing.*;
import java.awt.*;

public class MenuPrincipal extends JFrame {
    private final EstudianteController controlador;

    public MenuPrincipal() {
        controlador = new EstudianteController();
        setTitle("DUNAB | Sistema estudiantil");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(850, 520);
        setMinimumSize(new Dimension(720, 450));
        setLocationRelativeTo(null);
        construirInterfaz();
    }

    private void construirInterfaz() {
        setLayout(new BorderLayout());
        JPanel lateral = new JPanel();
        lateral.setBackground(Estilos.NEGRO);
        lateral.setPreferredSize(new Dimension(245, 0));
        lateral.setLayout(new BoxLayout(lateral, BoxLayout.Y_AXIS));
        lateral.setBorder(BorderFactory.createEmptyBorder(28, 22, 22, 22));

        JLabel marca = new JLabel("UNAB");
        marca.setForeground(Estilos.NARANJA);
        marca.setFont(new Font("Arial", Font.BOLD, 30));
        JLabel subtitulo = new JLabel("EXPERIENCIA UNIVERSITARIA");
        subtitulo.setForeground(Color.WHITE);
        subtitulo.setFont(new Font("Arial", Font.PLAIN, 10));
        JLabel frase = new JLabel("<html><div style='width:180px'>Cada encuentro<br>suma a tu futuro.</div></html>");
        frase.setForeground(Color.WHITE);
        frase.setFont(new Font("Arial", Font.BOLD, 22));
        JLabel descripcion = new JLabel("<html><div style='width:180px'>Consulta y organiza tu progreso académico desde un solo lugar.</div></html>");
        descripcion.setForeground(new Color(205, 205, 205));
        descripcion.setFont(new Font("Arial", Font.PLAIN, 13));
        lateral.add(marca);
        lateral.add(Box.createVerticalStrut(5));
        lateral.add(subtitulo);
        lateral.add(Box.createVerticalStrut(38));
        lateral.add(frase);
        lateral.add(Box.createVerticalStrut(18));
        lateral.add(descripcion);
        lateral.add(Box.createVerticalGlue());
        JLabel pie = new JLabel("PROYECTO ACADÉMICO DUNAB");
        pie.setForeground(new Color(160, 160, 160));
        pie.setFont(new Font("Arial", Font.PLAIN, 9));
        lateral.add(pie);

        JPanel contenido = new JPanel(new BorderLayout(15, 15));
        contenido.setBackground(Estilos.FONDO);
        contenido.setBorder(BorderFactory.createEmptyBorder(35, 38, 35, 38));
        JLabel bienvenida = new JLabel("<html><small style='color:#F57819'>ESPACIO DEL ESTUDIANTE</small><br><br><b>Bienvenido a DUNAB</b><br><small>Selecciona una opción para continuar.</small></html>");
        bienvenida.setFont(new Font("Arial", Font.PLAIN, 23));
        contenido.add(bienvenida, BorderLayout.NORTH);

        JPanel opciones = new JPanel(new GridLayout(0, 1, 0, 13));
        opciones.setOpaque(false);
        JButton login = boton("Iniciar sesión");
        JButton registro = boton("Crear una cuenta");
        JButton consulta = boton("Consultar estudiantes");
        JButton salir = boton("Salir");
        opciones.add(login);
        opciones.add(registro);
        opciones.add(consulta);
        opciones.add(salir);
        contenido.add(opciones, BorderLayout.CENTER);

        login.addActionListener(e -> new LoginFrame(controlador, this).setVisible(true));
        registro.addActionListener(e -> new RegistroFrame(controlador, this).setVisible(true));
        consulta.addActionListener(e -> mostrarEstudiantes());
        salir.addActionListener(e -> {
            int r = JOptionPane.showConfirmDialog(this, "¿Deseas cerrar el sistema?", "Confirmar salida", JOptionPane.YES_NO_OPTION);
            if (r == JOptionPane.YES_OPTION) dispose();
        });

        add(lateral, BorderLayout.WEST);
        add(contenido, BorderLayout.CENTER);
    }

    private JButton boton(String texto) {
        JButton b = new JButton(texto);
        b.setFont(new Font("Arial", Font.BOLD, 15));
        b.setFocusPainted(false);
        b.setBackground(Color.WHITE);
        b.setForeground(Estilos.NEGRO);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(225, 226, 229)),
                BorderFactory.createEmptyBorder(13, 16, 13, 16)));
        b.setHorizontalAlignment(SwingConstants.LEFT);
        return b;
    }

    private void mostrarEstudiantes() {
        StringBuilder texto = new StringBuilder("ESTUDIANTES REGISTRADOS\n\n");
        if (controlador.obtenerEstudiantes().isEmpty()) texto.append("Todavía no hay estudiantes registrados.");
        else for (modelo.Estudiante e : controlador.obtenerEstudiantes())
            texto.append(e.getNombre()).append(" | ").append(e.getCodigo()).append(" | ").append(e.getCorreo()).append("\n");
        JTextArea area = new JTextArea(texto.toString(), 12, 42);
        area.setEditable(false);
        JOptionPane.showMessageDialog(this, new JScrollPane(area), "Consulta", JOptionPane.INFORMATION_MESSAGE);
    }
}
