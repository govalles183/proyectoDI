package vista;

import controlador.EstudianteController;
import modelo.Usuario;
import javax.swing.*;
import java.awt.*;

public class LoginFrame extends JFrame {
    public LoginFrame(EstudianteController controlador, JFrame menu) {
        setTitle("DUNAB | Iniciar sesión");
        setSize(480, 350);
        setLocationRelativeTo(menu);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(25, 35, 25, 35));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2; c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(7, 5, 7, 5);
        JLabel titulo = new JLabel("Inicia sesión en DUNAB");
        titulo.setFont(Estilos.TITULO);
        p.add(titulo, c);

        c.gridwidth = 1; c.gridy++;
        p.add(new JLabel("Correo institucional o código"), c);
        c.gridy++;
        JTextField identificador = new JTextField(25);
        p.add(identificador, c);
        c.gridy++;
        p.add(new JLabel("Contraseña"), c);
        c.gridy++;
        JPasswordField contrasena = new JPasswordField(25);
        p.add(contrasena, c);
        c.gridy++;
        JButton entrar = new JButton("Iniciar sesión");
        entrar.setBackground(Estilos.NARANJA);
        entrar.setForeground(Color.WHITE);
        p.add(entrar, c);
        c.gridy++;
        JButton crear = new JButton("Crear una cuenta");
        p.add(crear, c);

        entrar.addActionListener(e -> {
            Usuario usuario = controlador.iniciarSesion(identificador.getText(), new String(contrasena.getPassword()));
            if (usuario == null) {
                JOptionPane.showMessageDialog(this, "Datos incorrectos. Verifica tu correo/código y contraseña.", "No se pudo ingresar", JOptionPane.WARNING_MESSAGE);
            } else {
                dispose();
                new PanelPrincipalFrame(controlador, usuario).setVisible(true);
            }
        });
        crear.addActionListener(e -> new RegistroFrame(controlador, menu).setVisible(true));
        add(p);
    }
}
