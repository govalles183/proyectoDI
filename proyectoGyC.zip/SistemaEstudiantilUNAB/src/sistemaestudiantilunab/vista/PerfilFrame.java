package vista;

import controlador.EstudianteController;
import modelo.Estudiante;
import javax.swing.*;
import java.awt.*;

public class PerfilFrame extends JFrame {
    public PerfilFrame(EstudianteController controlador, Estudiante estudiante) {
        setTitle("DUNAB | Perfil del estudiante");
        setSize(470, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(25, 35, 25, 35));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.gridy = 0; c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(8, 5, 8, 5);
        JLabel titulo = new JLabel("Perfil del estudiante");
        titulo.setFont(Estilos.TITULO);
        p.add(titulo, c);
        c.gridy++;
        p.add(new JLabel("Nombre completo"), c);
        c.gridy++;
        JTextField nombre = new JTextField(estudiante.getNombre(), 25); p.add(nombre, c);
        c.gridy++;
        p.add(new JLabel("Código estudiantil (no editable)"), c);
        c.gridy++;
        JTextField codigo = new JTextField(estudiante.getCodigo(), 25);
        codigo.setEditable(false); p.add(codigo, c);
        c.gridy++;
        p.add(new JLabel("Correo institucional"), c);
        c.gridy++;
        JTextField correo = new JTextField(estudiante.getCorreo(), 25); p.add(correo, c);
        c.gridy++;
        JButton guardar = new JButton("Guardar cambios");
        guardar.setBackground(Estilos.NARANJA); guardar.setForeground(Color.WHITE);
        p.add(guardar, c);

        guardar.addActionListener(e -> {
            if (!correo.getText().trim().contains("@")) {
                JOptionPane.showMessageDialog(this, "Escribe un correo válido.");
                return;
            }
            if (controlador.actualizarPerfil(estudiante, nombre.getText(), correo.getText())) {
                JOptionPane.showMessageDialog(this, "Perfil actualizado.");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudieron guardar los cambios.");
            }
        });
        add(p);
    }
}
