package vista;

import controlador.EstudianteController;
import javax.swing.*;
import java.awt.*;

public class RegistroFrame extends JFrame {
    public RegistroFrame(EstudianteController controlador, JFrame padre) {
        setTitle("DUNAB | Crear cuenta");
        setSize(500, 470);
        setLocationRelativeTo(padre);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createEmptyBorder(20, 35, 20, 35));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0; c.gridy = 0; c.gridwidth = 2; c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(6, 5, 6, 5);
        JLabel titulo = new JLabel("Crea tu cuenta");
        titulo.setFont(Estilos.TITULO);
        p.add(titulo, c);

        c.gridwidth = 1; c.gridy++;
        p.add(new JLabel("Nombre completo"), c);
        c.gridy++;
        JTextField nombre = new JTextField(25); p.add(nombre, c);
        c.gridy++;
        p.add(new JLabel("Código estudiantil"), c);
        c.gridy++;
        JTextField codigo = new JTextField(25); p.add(codigo, c);
        c.gridy++;
        p.add(new JLabel("Correo institucional"), c);
        c.gridy++;
        JTextField correo = new JTextField(25); p.add(correo, c);
        c.gridy++;
        p.add(new JLabel("Contraseña"), c);
        c.gridy++;
        JPasswordField clave = new JPasswordField(25); p.add(clave, c);
        c.gridy++;
        JButton crear = new JButton("Crear cuenta");
        crear.setBackground(Estilos.NARANJA); crear.setForeground(Color.WHITE);
        p.add(crear, c);

        crear.addActionListener(e -> {
            String email = correo.getText().trim();
            if (!email.contains("@")) {
                JOptionPane.showMessageDialog(this, "Escribe un correo válido.", "Revisar información", JOptionPane.WARNING_MESSAGE);
                return;
            }
            boolean ok = controlador.registrar(nombre.getText(), codigo.getText(), email, new String(clave.getPassword()));
            if (ok) {
                JOptionPane.showMessageDialog(this, "Cuenta creada correctamente. Ya puedes iniciar sesión.");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo registrar. Revisa que todos los campos estén completos y que el código/correo no exista.", "Error de registro", JOptionPane.ERROR_MESSAGE);
            }
        });
        add(p);
    }
}
