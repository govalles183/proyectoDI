package vista;

import java.awt.Color;
import java.awt.Font;

public final class Estilos {
    public static final Color NEGRO = new Color(27, 27, 29);
    public static final Color NARANJA = new Color(245, 120, 25);
    public static final Color FONDO = new Color(246, 247, 249);
    public static final Color GRIS = new Color(105, 108, 115);
    public static final Font TITULO = new Font("Arial", Font.BOLD, 22);
    public static final Font NORMAL = new Font("Arial", Font.PLAIN, 14);

    private Estilos() {}
}
