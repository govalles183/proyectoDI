package vista;

import controlador.EstudianteController;
import modelo.Usuario;
import modelo.Estudiante;
import javax.swing.*;
import java.awt.*;

public class PanelPrincipalFrame extends JFrame {
    public PanelPrincipalFrame(EstudianteController controlador, Usuario usuario) {
        Estudiante estudiante = usuario.getEstudiante();
        setTitle("DUNAB | Panel principal");
        setSize(780, 470);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel lateral = new JPanel();
        lateral.setBackground(Estilos.NEGRO);
        lateral.setPreferredSize(new Dimension(190, 0));
        lateral.setLayout(new BoxLayout(lateral, BoxLayout.Y_AXIS));
        lateral.setBorder(BorderFactory.createEmptyBorder(25, 18, 18, 18));
        JLabel logo = new JLabel("DUNAB");
        logo.setForeground(Estilos.NARANJA);
        logo.setFont(new Font("Arial", Font.BOLD, 25));
        lateral.add(logo);
        lateral.add(Box.createVerticalStrut(30));
        for (String s : new String[]{"Panel principal", "Encuentros", "Historial de DUNAB", "Ranking", "Notificaciones", "Mi progreso"}) {
            JLabel item = new JLabel("  " + s);
            item.setForeground(Color.WHITE);
            item.setBorder(BorderFactory.createEmptyBorder(10, 2, 10, 2));
            lateral.add(item);
        }

        JPanel main = new JPanel(new BorderLayout(15, 15));
        main.setBackground(Estilos.FONDO);
        main.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        JLabel saludo = new JLabel("<html><small>ESPACIO DEL ESTUDIANTE</small><br><br><b>Hola, " + escapar(estudiante.getNombre()) + "</b><br><small>Este es el resumen de tu cuenta en DUNAB.</small></html>");
        saludo.setFont(new Font("Arial", Font.PLAIN, 23));
        main.add(saludo, BorderLayout.NORTH);

        JPanel tarjetas = new JPanel(new GridLayout(2, 2, 12, 12));
        tarjetas.setOpaque(false);
        tarjetas.add(tarjeta("Perfil del estudiante", "Consulta y actualiza tus datos."));
        tarjetas.add(tarjeta("Encuentros", "Explora actividades universitarias."));
        tarjetas.add(tarjeta("Historial", "Consulta tu actividad reciente."));
        tarjetas.add(tarjeta("Mi progreso", "Revisa tu avance académico."));
        main.add(tarjetas, BorderLayout.CENTER);

        JPanel abajo = new JPanel(new FlowLayout(FlowLayout.LEFT));
        abajo.setOpaque(false);
        JButton perfil = new JButton("Ver mi perfil");
        JButton cerrar = new JButton("Cerrar sesión");
        perfil.setBackground(Estilos.NARANJA); perfil.setForeground(Color.WHITE);
        abajo.add(perfil); abajo.add(cerrar);
        main.add(abajo, BorderLayout.SOUTH);

        perfil.addActionListener(e -> new PerfilFrame(controlador, estudiante).setVisible(true));
        cerrar.addActionListener(e -> dispose());

        add(lateral, BorderLayout.WEST);
        add(main, BorderLayout.CENTER);
    }

    private JPanel tarjeta(String titulo, String detalle) {
        JPanel p = new JPanel(new BorderLayout(5, 10));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(230, 230, 230)),
                BorderFactory.createEmptyBorder(18, 18, 18, 18)));
        JLabel t = new JLabel(titulo);
        t.setFont(new Font("Arial", Font.BOLD, 15));
        JLabel d = new JLabel("<html>" + detalle + "</html>");
        d.setForeground(Estilos.GRIS);
        p.add(t, BorderLayout.NORTH); p.add(d, BorderLayout.CENTER);
        return p;
    }

    private String escapar(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
