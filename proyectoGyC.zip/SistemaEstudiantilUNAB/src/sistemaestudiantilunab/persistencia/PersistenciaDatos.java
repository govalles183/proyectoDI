package persistencia;

import modelo.Usuario;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class PersistenciaDatos {
    private final File archivo;

    public PersistenciaDatos() {
        archivo = new File("datos", "usuarios.dat");
    }

    @SuppressWarnings("unchecked")
    public List<Usuario> cargar() {
        if (!archivo.exists()) return new ArrayList<Usuario>();
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(archivo))) {
            return (List<Usuario>) entrada.readObject();
        } catch (IOException | ClassNotFoundException | ClassCastException ex) {
            return new ArrayList<Usuario>();
        }
    }

    public boolean guardar(List<Usuario> usuarios) {
        File carpeta = archivo.getParentFile();
        if (!carpeta.exists() && !carpeta.mkdirs()) return false;
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(archivo))) {
            salida.writeObject(usuarios);
            return true;
        } catch (IOException ex) {
            return false;
        }
    }
}
