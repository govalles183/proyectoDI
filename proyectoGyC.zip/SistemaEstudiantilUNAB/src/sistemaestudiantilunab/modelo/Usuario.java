package modelo;

import java.io.Serializable;

public class Usuario implements Serializable {
    private static final long serialVersionUID = 1L;
    private Estudiante estudiante;
    private String contrasena;

    public Usuario(Estudiante estudiante, String contrasena) {
        this.estudiante = estudiante;
        this.contrasena = contrasena;
    }

    public Estudiante getEstudiante() { return estudiante; }
    public void setEstudiante(Estudiante estudiante) { this.estudiante = estudiante; }
    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }
}
