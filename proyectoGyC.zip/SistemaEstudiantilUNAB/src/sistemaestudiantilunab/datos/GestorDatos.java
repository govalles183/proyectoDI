package datos;

import modelo.Estudiante;
import modelo.Usuario;
import persistencia.PersistenciaDatos;
import java.util.ArrayList;
import java.util.List;

public class GestorDatos {
    private final List<Usuario> usuarios;
    private final PersistenciaDatos persistencia;

    public GestorDatos() {
        persistencia = new PersistenciaDatos();
        usuarios = new ArrayList<Usuario>(persistencia.cargar());
    }

    public boolean registrar(String nombre, String codigo, String correo, String contrasena) {
        if (nombre == null || nombre.trim().isEmpty()
                || codigo == null || codigo.trim().isEmpty()
                || correo == null || correo.trim().isEmpty()
                || contrasena == null || contrasena.trim().isEmpty()) return false;
        if (buscarPorCodigo(codigo) != null || buscarPorCorreo(correo) != null) return false;

        Estudiante estudiante = new Estudiante(nombre.trim(), codigo.trim(), correo.trim());
        usuarios.add(new Usuario(estudiante, contrasena));
        return persistencia.guardar(usuarios);
    }

    public Usuario autenticar(String identificador, String contrasena) {
        for (Usuario usuario : usuarios) {
            Estudiante e = usuario.getEstudiante();
            if ((e.getCorreo().equalsIgnoreCase(identificador.trim())
                    || e.getCodigo().equalsIgnoreCase(identificador.trim()))
                    && usuario.getContrasena().equals(contrasena)) {
                return usuario;
            }
        }
        return null;
    }

    public Estudiante buscarPorCodigo(String codigo) {
        for (Usuario u : usuarios) {
            if (u.getEstudiante().getCodigo().equalsIgnoreCase(codigo.trim())) return u.getEstudiante();
        }
        return null;
    }

    private Usuario buscarPorCorreo(String correo) {
        for (Usuario u : usuarios) {
            if (u.getEstudiante().getCorreo().equalsIgnoreCase(correo.trim())) return u;
        }
        return null;
    }

    public List<Estudiante> listarEstudiantes() {
        List<Estudiante> lista = new ArrayList<Estudiante>();
        for (Usuario u : usuarios) lista.add(u.getEstudiante());
        return lista;
    }

    public boolean actualizarPerfil(Estudiante estudiante, String nombre, String correo) {
        if (estudiante == null || nombre == null || nombre.trim().isEmpty()
                || correo == null || correo.trim().isEmpty()) return false;
        estudiante.setNombre(nombre.trim());
        estudiante.setCorreo(correo.trim());
        return persistencia.guardar(usuarios);
    }
}
