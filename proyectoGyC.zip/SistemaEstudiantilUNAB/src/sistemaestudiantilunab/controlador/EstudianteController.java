package controlador;

import datos.GestorDatos;
import modelo.Estudiante;
import modelo.Usuario;
import java.util.List;

public class EstudianteController {
    private final GestorDatos gestor;

    public EstudianteController() {
        gestor = new GestorDatos();
    }

    public boolean registrar(String nombre, String codigo, String correo, String contrasena) {
        return gestor.registrar(nombre, codigo, correo, contrasena);
    }

    public Usuario iniciarSesion(String identificador, String contrasena) {
        return gestor.autenticar(identificador, contrasena);
    }

    public List<Estudiante> obtenerEstudiantes() {
        return gestor.listarEstudiantes();
    }

    public boolean actualizarPerfil(Estudiante estudiante, String nombre, String correo) {
        return gestor.actualizarPerfil(estudiante, nombre, correo);
    }
}
