import javax.swing.SwingUtilities;
import vista.MenuPrincipal;

public class App {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MenuPrincipal().setVisible(true));
    }
}
